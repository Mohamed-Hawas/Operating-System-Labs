gcc -pthread threads.c -o threads
./threads 
